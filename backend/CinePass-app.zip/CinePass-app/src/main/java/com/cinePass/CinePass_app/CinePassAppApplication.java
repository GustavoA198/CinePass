package com.cinePass.CinePass_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CinePassAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CinePassAppApplication.class, args);
	}

}
